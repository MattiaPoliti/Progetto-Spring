package it.mattia.MySpringDataJDBC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySpringDataJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
