package it.mattia.MySpringDataJDBC;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component
public class MyUserRowMapper implements RowMapper<MyUser>{
	
	@Override
	 // Itera internamente ResultSet e crea le singole istanze
	 public MyUser mapRow(ResultSet myResultSet, int myRowNumber) throws SQLException {   
	  return new MyUser(
	    myResultSet.getString("nome"), 
	    myResultSet.getString("cognome"), 
	    myResultSet.getInt("eta")
	  );  
	 }
}
