package it.mattia.MySpringDataJDBC;

import java.util.List;


/* DAO (Data Access Object)
Pattern architetturale per la gestione della persistenza
Fondamentalmente una classe con relativi metodi che rappresenta un'entità tabellare di un RDBMS.
Consente di stratificare e isolare l'accesso al database creando un maggiore livello di astrazione,
una rigida separazione tra le componenti di un'applicazione ed una più facile manutenibilità. 
*/

public interface MyUserDAOInterface<T> {
	// Senza RowMapper
	 public void getAll();
	 public void insert(T t); 
	 // Usa RowMapper
	 public List<T> getAllRowMapper();
}
