package it.mattia.MySpringDataJDBC;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class MyUserDAO implements MyUserDAOInterface<MyUser>{
	@Autowired
	 JdbcTemplate jdbcTemplate;
	 
	 @Override
	 public void getAll() {
	  jdbcTemplate.queryForList("SELECT * FROM myuser")
	  .forEach(row -> System.out.println(row.get("nome") + " " + row.get("cognome") + " " +row.get("eta"))); 
	 }  
	  
	 @Override
	 public void insert(MyUser myUser) {
	  jdbcTemplate.update("INSERT INTO myuser (nome, cognome, eta) VALUES(?, ?, ?)", myUser.getNome(), myUser.getCognome(), myUser.getEta());
	 }

	// Usa RowMapper
	 @Override
	 public List<MyUser> getAllRowMapper() {  
	  try {
	   // Ritorna la List
	   return jdbcTemplate.query("SELECT * FROM myuser", new MyUserRowMapper());
	  } catch(DataAccessException e) {
	   System.out.println("DataAccessException: " + e);
	  }  
	  // Oppure ritorna una collezione vuota
	  return Collections.emptyList();  
	 }
	 
}
