package it.mattia.MySpringDataJDBC;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;

@Configuration(enforceUniqueMethods = false)
public class MyConfig {
	/*
	@Bean    
    MyUser myUser() {
        return new MyUser(null, null, 0);
    }
	*/
	
    @Bean("myuser")
    @Scope("prototype") 
    @Primary   
    MyUser myUser(String nome, String cognome, int eta) {
        return new MyUser(nome, cognome, eta);
    }
}
