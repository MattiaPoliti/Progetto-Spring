package it.mattia.MySpringDataJDBC;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class MyCRUD implements CommandLineRunner{
	@Autowired
	 ApplicationContext applicationContext;  
	 @Autowired
	 JdbcTemplate jdbcTemplate; 
	 @Autowired
	 NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	@Autowired
	 MyUserRowMapper myUserRowMapper;
	 
	 @Autowired
	 MyUserDAO myUserDAO;

	@Override
	public void run(String... args) throws Exception {
		/* Senza DAO */
		  // Statement  
		  //jdbcTemplate.update("INSERT INTO myuser (nome, cognome, eta) VALUES('Sara','Gialli', 33)"); 
		  //jdbcTemplate.update("UPDATE myuser SET eta = '99' WHERE nome = 'Sara'");
		  //jdbcTemplate.update("DELETE FROM myuser WHERE nome = 'Sara' AND cognome = 'Gialli'"); 
		  //queryForList(): utilizzato per recuperare liste di record
		  //jdbcTemplate.queryForList("SELECT * FROM myuser")
		  //.forEach(row -> System.out.println(row.get("nome") + " " + row.get("cognome") + " " +row.get("eta"))); 
		  // queryForObject(): utilizzato per recuperare un singolo valore/oggetto
		  //int myCount = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM myuser", Integer.class);
		  //System.out.println("MyCount: " + myCount);
		  /*
		  // execute(): per istruzioni DDL (Data Definition Language)   
		  jdbcTemplate.execute("CREATE TABLE mynewuser ("
		    + "id INT(3) AUTO_INCREMENT,"
		    + "name VARCHAR(25),"
		    + "surname VARCHAR(50),"
		    + "age INT(3),"
		    + "PRIMARY KEY(id)"
		    + ");"
		  );    
		  */
		  
		  /* RowMapper
		  Consente di ottenere come risultato oggetti e non semplici record */  
		  // Usa l'implementazione di RowMapper 
		  //jdbcTemplate.query("SELECT * FROM myuser", myUserRowMapper)
		  //jdbcTemplate.query("SELECT * FROM myuser", applicationContext.getBean(MyUserRowMapper.class))
		  //jdbcTemplate.query("SELECT * FROM myuser", new MyUserRowMapper())
		  //.forEach(myUser -> System.out.println(myUser));
		  
		  /* Prepared Statement */
		  String nome = "Aldo";
		  String cognome = "Rossi";
		  int eta = 33;
		  //jdbcTemplate.update("INSERT INTO myuser (nome, cognome, eta) VALUES(?, ?, ?)", nome, cognome, eta);
		  //jdbcTemplate.update("UPDATE myuser SET eta = ? WHERE nome = ?", 44, "Aldo");
		  //jdbcTemplate.update("DELETE FROM myuser WHERE nome = ?", "Aldo");
		  //jdbcTemplate.queryForList("SELECT * FROM myuser WHERE nome = ? AND eta = ?", "Sara", 32)
		  //.forEach(myRow -> System.out.println(myRow));
		  
		  /* NamedParameterJdbcTemplate 
		  // Avvolge JbdcTemplate e fornisce un'alternativa all'uso di ? per specificare i parametri
		  // MapSqlParameterSource: consente di abbinare il valore ai parametri
		  String myInsert = "INSERT INTO myuser (nome, cognome, eta) VALUES (:nome, :cognome, :eta)";    
		  MapSqlParameterSource myMapParams = new MapSqlParameterSource();
		  myMapParams.addValue("nome", "Ajeje").addValue("cognome", "Brazorf").addValue("eta", 33);  
		  namedParameterJdbcTemplate.update(myInsert, myMapParams);
		  */
		  
		  /* BeanPropertySqlParameterSource 
		  // Esamina le proprietà di un Spring Bean per generare i nomi dei parametri 
		  String myInsertB = "INSERT INTO myuser (nome, cognome, eta) VALUES (:nome, :cognome, :eta)";
		  // N.B. Il nome del bean deve essere diverso dal nome del metodo beanizzante
		  MyUser myUser = (MyUser) applicationContext.getBean("myuser","Carlo","Magenta",44);   
		     BeanPropertySqlParameterSource myBeanParam = new BeanPropertySqlParameterSource(myUser);     
		  namedParameterJdbcTemplate.update(myInsertB, myBeanParam);
		  */
		  
		  /* Stored Procedure 
		  // Esistono diversi modi per chiamare le stored procedure in Spring 
		  // JdbcTemplate è il più semplice 
		  jdbcTemplate.update("call myProcedureUpdate(?, ?)", "Lallo", "Carlo");
		  */
		  
		  /*
		  MyUser myNewUser = (MyUser) applicationContext.getBean("myuser", "Lisa", "White", 45);
		  myUserDAO.insert(myNewUser); 
		  // Usa RowMapper
		  myUserDAO.getAllRowMapper().forEach(myuser -> System.out.println(myuser));*/
		  
		  
	}
	 
	 
}
